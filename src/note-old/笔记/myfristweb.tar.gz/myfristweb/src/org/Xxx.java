package org;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by andilyliao on 19-7-23.
 */
public class Xxx extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String un=request.getParameter("un");
        String pw=request.getParameter("pw");
        String res="";
        if(un.equals("aaa")&&pw.equals("bbb")){
            res="ok";
        }else{
            res="error";
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        out.write("{isok:\""+res+"\"}");
        out.flush();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
