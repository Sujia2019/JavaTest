package org;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Base64;

/**
 * Created by andilyliao on 19-7-23.
 */
public class Test {
    public static void main(String[] args) {
        String str="我爱中国!abc";
        byte[] b=Base64.getEncoder().encode(str.getBytes());
        System.out.println(new String(b));
        byte[] t=Base64.getDecoder().decode("5oiR54ix5Lit5Zu9IQ==".getBytes());
        System.out.println(new String(t));

        String yyy=URLEncoder.encode("我爱中国!abc");
        System.out.println(yyy);
        String xxx= URLDecoder.decode("%E6%88%91");
        System.out.println(xxx);
    }
}
